*PADS-LIBRARY-PART-TYPES-V9*

USB6B1RL SOIC127P600X175-8N I ANA 7 1 0 0 0
TIMESTAMP 2025.12.23.13.17.25
"Mouser Part Number" 511-USB6B1RL
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/STMicroelectronics/USB6B1RL?qs=Ctxo64yJVFuZb8Hhk%2F3CCQ%3D%3D
"Manufacturer_Name" STMicroelectronics
"Manufacturer_Part_Number" USB6B1RL
"Description" TVS Diode Array Bi-Directional USB6B1RL, 500W SOIC 8-Pin
"Datasheet Link" https://www.st.com/resource/en/datasheet/usb6b1.pdf
"Geometry.Height" 1.75mm
GATE 1 8 0
USB6B1RL
1 0 U VCC_1
2 0 U I/O1_1
3 0 U I/O2_1
4 0 U GND_1
8 0 U VCC_2
7 0 U I/O1_2
6 0 U I/O2_2
5 0 U GND_2

*END*
*REMARK* SamacSys ECAD Model
5552/1387872/2.50/8/2/Integrated Circuit
