*PADS-LIBRARY-PART-TYPES-V9*

TPIC6C595D SOIC127P600X175-16N I ANA 7 1 0 0 0
TIMESTAMP 2025.12.23.12.44.43
"Mouser Part Number" 595-TPIC6C595D
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Texas-Instruments/TPIC6C595D?qs=%252BWCn1GN4mVx7%252BsUWaxi9Lw%3D%3D
"Manufacturer_Name" Texas Instruments
"Manufacturer_Part_Number" TPIC6C595D
"Description" Texas Instruments TPIC6C595D 8-stage Shift Register, Serial to Serial/Parallel, 5V, 16-Pin SOIC
"Datasheet Link" http://www.ti.com/lit/gpn/TPIC6C595
"Geometry.Height" 1.75mm
GATE 1 16 0
TPIC6C595D
1 0 U VCC
2 0 U SER_IN
3 0 U DRAIN0
4 0 U DRAIN1
5 0 U DRAIN2
6 0 U DRAIN3
7 0 U \CLR
8 0 U \G
16 0 U GND
15 0 U SRCK
14 0 U DRAIN7
13 0 U DRAIN6
12 0 U DRAIN5
11 0 U DRAIN4
10 0 U RCK
9 0 U SER_OUT

*END*
*REMARK* SamacSys ECAD Model
526100/1387872/2.50/16/3/Integrated Circuit
