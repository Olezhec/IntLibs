*PADS-LIBRARY-PART-TYPES-V9*

NA-24W-K NA24WK I RLY 6 1 0 0 0
TIMESTAMP 2025.12.23.12.10.48
"Mouser Part Number" 817-NA-24W-K
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Fujitsu/NA-24W-K?qs=CaoHQtVDS05ygNhX5HGm5w%3D%3D
"Manufacturer_Name" FCL Components
"Manufacturer_Part_Number" NA-24W-K
"Description" Fujitsu DPDT Non-Latching Relay PCB Mount, 24V dc Coil
"Datasheet Link" 
GATE 1 8 0
NA-24W-K
1 0 U COIL_+
3 0 U NC_1
4 0 U COM_1
5 0 U NO_1
8 0 U NO_2
9 0 U COM_2
10 0 U NC_2
12 0 U COIL_-

*END*
*REMARK* SamacSys ECAD Model
1067922/1387872/2.50/8/4/Relay or Contactor
