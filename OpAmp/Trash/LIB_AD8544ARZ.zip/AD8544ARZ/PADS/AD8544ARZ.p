*PADS-LIBRARY-PART-TYPES-V9*

AD8544ARZ SOIC127P600X175-14N I ANA 7 1 0 0 0
TIMESTAMP 2025.12.23.11.30.52
"Mouser Part Number" 584-AD8544ARZ
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Analog-Devices/AD8544ARZ?qs=%2FtpEQrCGXCzsY1tAHopYQw%3D%3D
"Manufacturer_Name" Analog Devices
"Manufacturer_Part_Number" AD8544ARZ
"Description" CMOS Rail-to-Rail General-Purpose Amplifiers
"Datasheet Link" https://www.analog.com/AD8544/datasheet
"Geometry.Height" 1.75mm
GATE 1 14 0
AD8544ARZ
1 0 U OUT_A
2 0 U -IN_A
3 0 U +IN_A
4 0 U V+
5 0 U +IN_B
6 0 U -IN_B
7 0 U OUT_B
14 0 U OUT_D
13 0 U -IN_D
12 0 U +IN_D
11 0 U V-
10 0 U +IN_C
9 0 U -IN_C
8 0 U OUT_C

*END*
*REMARK* SamacSys ECAD Model
5356456/1387872/2.50/14/2/Integrated Circuit
