*PADS-LIBRARY-PART-TYPES-V9*

BC817_215 SOT95P230X110-3N I TRX 7 1 0 0 0
TIMESTAMP 2025.12.23.12.28.17
"Mouser Part Number" 771-BC817-T/R
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Nexperia/BC817215?qs=me8TqzrmIYXz7pTxqNMGNQ%3D%3D
"Manufacturer_Name" Nexperia
"Manufacturer_Part_Number" BC817,215
"Description" BC817; BC817W; BC337 - 45 V, 500 mA NPN general-purpose transistors
"Datasheet Link" https://assets.nexperia.com/documents/data-sheet/BC817_SER.pdf
"Geometry.Height" 1.1mm
GATE 1 3 0
BC817_215
1 0 U B
2 0 U E
3 0 U C

*END*
*REMARK* SamacSys ECAD Model
663534/1387872/2.50/3/2/Transistor BJT NPN
